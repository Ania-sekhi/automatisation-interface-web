"""VéloCité."""
__version__ = "1.0"
LIVRAISON = "Livraison 1"
