"""Cycle de vie d'une location (R-10, R-11, R-12) : machine à états.

L'heure courante est toujours passée en paramètre (`maintenant`) : le temps est ainsi
contrôlable dans les tests, sans attendre 15 minutes réelles.
"""
import math
from datetime import datetime, timedelta

RESERVEE, EN_COURS, EN_PANNE = "RESERVEE", "EN_COURS", "EN_PANNE"
TERMINEE, PAYEE, ANNULEE, EXPIREE = "TERMINEE", "PAYEE", "ANNULEE", "EXPIREE"
ETATS_ACTIFS = {RESERVEE, EN_COURS}
DELAI_EXPIRATION = timedelta(minutes=15)                 # R-10

TRANSITIONS = {                                           # R-12 : (état de départ, événement) -> état d'arrivée
    (RESERVEE, "deverrouiller"): EN_COURS,
    (RESERVEE, "annuler"): ANNULEE,
    (RESERVEE, "expirer"): EXPIREE,
    (EN_COURS, "rendre"): TERMINEE,
    (EN_COURS, "annuler"): ANNULEE,
    (EN_COURS, "signaler_panne"): EN_PANNE,
    (EN_PANNE, "rendre"): TERMINEE,
    (TERMINEE, "payer"): PAYEE,
}


class TransitionInterdite(Exception):
    """L'événement n'est pas autorisé dans l'état courant."""


class Location:
    def __init__(self, client: str, type_velo: str, maintenant: datetime):
        self.client = client
        self.type_velo = type_velo
        self.etat = RESERVEE
        self.reservee_a = maintenant
        self.debut = None
        self.fin_facturation = None
        self.prix = None

    @property
    def active(self) -> bool:
        return self.etat in ETATS_ACTIFS

    def _transition(self, evenement: str) -> None:
        nouvel_etat = TRANSITIONS.get((self.etat, evenement))
        if nouvel_etat is None:
            raise TransitionInterdite(f"Action « {evenement} » impossible dans l'état {self.etat}")
        self.etat = nouvel_etat

    def verifier_expiration(self, maintenant: datetime) -> None:
        """R-10 : une réservation expire au-delà de 15 minutes (15 minutes pile reste acceptée)."""
        if self.etat == RESERVEE and maintenant - self.reservee_a >= DELAI_EXPIRATION:
            self._transition("expirer")

    def deverrouiller(self, maintenant: datetime) -> None:
        self.verifier_expiration(maintenant)
        if self.etat == EXPIREE:
            raise TransitionInterdite("Réservation expirée")
        self._transition("deverrouiller")
        self.debut = maintenant

    def annuler(self, maintenant: datetime) -> None:
        self.verifier_expiration(maintenant)
        self._transition("annuler")

    def signaler_panne(self, maintenant: datetime) -> None:
        self._transition("signaler_panne")
        self.fin_facturation = maintenant                  # R-11

    def rendre(self, maintenant: datetime) -> int:
        """Termine la location et retourne la durée facturable en minutes (R-02, R-11)."""
        self._transition("rendre")
        fin = self.fin_facturation or maintenant
        self.fin_facturation = fin
        return max(1, math.ceil((fin - self.debut).total_seconds() / 60))

    def payer(self) -> None:
        self._transition("payer")
