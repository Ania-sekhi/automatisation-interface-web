"""Service VéloCité : orchestre clients, locations, tarification et paiement (niveau intégration)."""
from datetime import datetime
from typing import Protocol

from . import tarif
from .location import Location, TransitionInterdite


class PasserellePaiement(Protocol):
    def debiter(self, client: str, centimes: int) -> bool: ...


class ServiceErreur(Exception):
    pass


class ServiceVeloCite:
    def __init__(self, paiement: PasserellePaiement):
        self.paiement = paiement
        self.clients: dict[str, dict] = {}
        self.locations: list[Location] = []

    def inscrire(self, client: str, age: int, abonne: bool = False) -> None:
        self.clients[client] = {"age": age, "abonne": abonne}

    def location_active(self, client: str, maintenant: datetime) -> Location | None:
        for location in self.locations:
            if location.client == client:
                location.verifier_expiration(maintenant)
                if location.active:
                    return location
        return None

    def reserver(self, client: str, type_velo: str, maintenant: datetime) -> Location:
        if client not in self.clients:
            raise ServiceErreur("Client inconnu")
        tarif.verifier_eligibilite(type_velo, self.clients[client]["age"])        # R-01
        if self.location_active(client, maintenant):                              # R-09
            raise ServiceErreur("Une location est déjà en cours pour ce client")
        location = Location(client, type_velo, maintenant)
        self.locations.append(location)
        return location

    def terminer(self, location: Location, maintenant: datetime) -> int:
        """Retour du vélo : calcule et mémorise le prix (CA-02.1)."""
        minutes = location.rendre(maintenant)
        profil = self.clients[location.client]
        location.prix = tarif.calculer_prix(minutes, location.type_velo, profil["age"], profil["abonne"])
        return location.prix

    def payer(self, location: Location) -> bool:
        """CA-02.3 : si le paiement est refusé, la location reste TERMINEE (à payer)."""
        if location.prix is None:
            raise TransitionInterdite("La location n'est pas terminée")
        location.payer()
        return self.paiement.debiter(location.client, location.prix)
