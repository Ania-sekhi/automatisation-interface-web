"""VéloCité."""
__version__ = "3.0"
LIVRAISON = "Livraison 3"
