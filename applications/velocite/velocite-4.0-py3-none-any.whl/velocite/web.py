"""Interface web de la borne VéloCité (serveur local, sans dépendance)."""
import json
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from . import __version__, LIVRAISON
from .borne import Borne
from .tarif import TarifErreur, calculer_prix, formater

LIBELLE_PAYER = "Régler"

PAGE = """<!doctype html>
<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>VéloCité — Borne de location</title>
<style>
:root{--fond:#f3f5f8;--carte:#fff;--texte:#1d2733;--doux:#5b6878;--bord:#d9dee5;--accent:#0f6e5c;--accent2:#e8f4f1;--erreur:#b42318}
*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,"Segoe UI",sans-serif;background:var(--fond);color:var(--texte)}
header{background:var(--accent);color:#fff;padding:14px 24px;display:flex;justify-content:space-between;align-items:center}
header h1{font-size:20px;margin:0}header span{font-size:13px;background:rgba(255,255,255,.18);padding:4px 10px;border-radius:12px}
main{max-width:1100px;margin:20px auto;padding:0 16px;display:grid;grid-template-columns:1fr 1.4fr;gap:16px}
section{background:var(--carte);border:1px solid var(--bord);border-radius:10px;padding:16px}
h2{font-size:16px;margin:0 0 12px}h3{font-size:13px;text-transform:uppercase;letter-spacing:.04em;color:var(--doux);margin:14px 0 8px}
label{display:block;font-size:13px;color:var(--doux);margin:8px 0 3px}
input[type=text],select{width:100%;padding:8px;border:1px solid var(--bord);border-radius:6px;font-size:14px}
.case{display:flex;align-items:center;gap:6px;margin-top:10px}.case label{margin:0;color:var(--texte)}
.ligne{display:grid;grid-template-columns:1fr 1fr;gap:10px}
button{margin-top:10px;padding:8px 12px;border:1px solid var(--accent);background:var(--accent);color:#fff;border-radius:6px;font-size:14px;cursor:pointer}
button.second{background:#fff;color:var(--accent)}
.actions{display:flex;flex-wrap:wrap;gap:6px}
.resultat{margin-top:12px;padding:12px;border-radius:8px;background:var(--accent2);font-size:18px;font-weight:600;min-height:48px}
#horloge{font-size:22px;font-weight:700;font-variant-numeric:tabular-nums}
.message{grid-column:1/-1}#message{font-size:16px;font-weight:600;padding:10px;border-radius:8px;background:var(--accent2);min-height:44px}
#journal{margin:10px 0 0;padding-left:18px;color:var(--doux);font-size:13px;max-height:160px;overflow:auto}
footer{text-align:center;color:var(--doux);font-size:12px;margin:10px 0 24px}
@media(max-width:800px){main{grid-template-columns:1fr}}
</style></head>
<body data-reponses="0">
<header><h1>🚲 VéloCité — Borne de location</h1><span id="version">__LIVRAISON__ · v__VERSION__</span></header>
<main>
<section aria-labelledby="t-simu">
  <h2 id="t-simu">Simulateur de tarif</h2>
  <label for="duree">Durée (min)</label><input type="text" id="duree">
  <label for="type">Vélo</label><select id="type"><option value="classique">Classique</option><option value="electrique">Électrique</option></select>
  <label for="age">Âge</label><input type="text" id="age">
  <div class="case"><input type="checkbox" id="abonne"><label for="abonne">Abonné</label></div>
  <button id="calculer">Calculer le prix</button>
  <div class="resultat" id="prix-resultat" role="status"></div>
</section>
<section aria-labelledby="t-borne">
  <h2 id="t-borne">Borne</h2>
  <div class="ligne">
    <div><h3>Horloge simulée</h3><div id="horloge">09:00:00</div>
      <label for="attente">Avancer de (minutes ou mm:ss)</label><input type="text" id="attente">
      <button class="second" id="avancer">Avancer l'horloge</button></div>
    <div><h3>Inscription</h3>
      <label for="nom">Nom</label><input type="text" id="nom">
      <label for="age-client">Âge du client</label><input type="text" id="age-client">
      <div class="case"><input type="checkbox" id="abonne-client"><label for="abonne-client">Client abonné</label></div>
      <button id="inscrire">Inscrire</button></div>
  </div>
  <h3>Location</h3>
  <div class="ligne">
    <div><label for="client">Client</label><input type="text" id="client"></div>
    <div><label for="velo">Vélo à louer</label><select id="velo"><option value="classique">Classique</option><option value="electrique">Électrique</option><option value="tandem">Tandem</option></select></div>
  </div>
  <div class="actions">
    <button data-cmd="reserver" data-velo="1">Réserver</button><button data-cmd="deverrouiller">Déverrouiller</button>
    <button data-cmd="panne">Signaler une panne</button><button data-cmd="rendre">Rendre le vélo</button>
    <button data-cmd="payer">__PAYER__</button><button data-cmd="annuler">Annuler</button>
    <button class="second" data-cmd="etat">Voir l'état</button>
  </div>
  <div class="ligne">
    <div><h3>Banque simulée</h3><label for="banque">Paiements</label>
      <select id="banque"><option value="accepte">Accepter les paiements</option><option value="refuse">Refuser les paiements</option></select></div>
    <div><h3>Contrôle</h3><button class="second" id="debits">Voir les débits</button> <button class="second" id="reset">Réinitialiser la borne</button></div>
  </div>
</section>
<section class="message" aria-labelledby="t-msg">
  <h2 id="t-msg">Message de la borne</h2>
  <div id="message" role="status"></div>
  <ol id="journal" reversed></ol>
</section>
</main>
<footer>VéloCité — application de démonstration (horloge et banque simulées)</footer>
<script>
const $ = s => document.querySelector(s);
let n = 0;
function compter(){ document.body.dataset.reponses = ++n; }
function afficher(texte){
  $('#message').textContent = texte;
  const li = document.createElement('li'); li.textContent = $('#horloge').textContent + ' — ' + texte;
  $('#journal').prepend(li); compter();
}
async function appeler(url, corps){
  const r = await fetch(url, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(corps||{})});
  return r.json();
}
async function borne(commande){
  const j = await appeler('/api/borne', {commande});
  $('#horloge').textContent = j.heure; afficher(j.reponse);
}
$('#calculer').onclick = async () => {
  const j = await appeler('/api/prix', {duree: $('#duree').value, type: $('#type').value, age: $('#age').value, abonne: $('#abonne').checked});
  $('#prix-resultat').textContent = j.texte; compter();
};
$('#inscrire').onclick = async () => {
  const nom = $('#nom').value.trim(), age = $('#age-client').value.trim();
  if (!nom || !age) { afficher('Erreur : saisissez le nom et l\\'âge du client'); return; }
  await borne(`client ${nom} ${age}${$('#abonne-client').checked ? ' abonne' : ''}`);
  if ($('#message').textContent.startsWith('Client')) $('#client').value = nom;
};
document.querySelectorAll('.actions button').forEach(b => b.onclick = async () => {
  const client = $('#client').value.trim();
  if (!client) { afficher('Erreur : saisissez le nom du client'); return; }
  await borne(`${b.dataset.cmd} ${client}${b.dataset.velo ? ' ' + $('#velo').value : ''}`);
});
$('#avancer').onclick = () => borne(`attendre ${$('#attente').value.trim()}`);
$('#banque').onchange = () => borne(`paiement ${$('#banque').value}`);
$('#debits').onclick = () => borne('debits');
$('#reset').onclick = async () => {
  const j = await appeler('/api/reset'); $('#journal').innerHTML = ''; $('#banque').value = 'accepte';
  $('#horloge').textContent = j.heure; afficher(j.reponse);
};
</script></body></html>"""


class Application:
    def __init__(self):
        self.borne = Borne()

    def heure(self):
        return f"{self.borne.maintenant:%H:%M:%S}"


def prix(corps):
    try:
        duree, age = int(str(corps.get("duree", "")).strip()), int(str(corps.get("age", "")).strip())
    except ValueError:
        return "Erreur : la durée et l'âge doivent être des nombres entiers"
    try:
        return f"Prix : {formater(calculer_prix(duree, corps.get('type', 'classique'), age, bool(corps.get('abonne'))))}"
    except TarifErreur as erreur:
        return f"Erreur : {erreur}"


def fabriquer_gestionnaire(app):
    class Gestionnaire(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def envoyer(self, code, contenu, type_mime):
            donnees = contenu.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", type_mime + "; charset=utf-8")
            self.send_header("Content-Length", str(len(donnees)))
            self.end_headers()
            self.wfile.write(donnees)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                page = (PAGE.replace("__LIVRAISON__", LIVRAISON).replace("__VERSION__", __version__)
                        .replace("__PAYER__", LIBELLE_PAYER))
                self.envoyer(200, page, "text/html")
            else:
                self.envoyer(404, "Page introuvable", "text/plain")

        def do_POST(self):
            longueur = int(self.headers.get("Content-Length", 0))
            corps = json.loads(self.rfile.read(longueur) or b"{}")
            if self.path == "/api/borne":
                reponse = app.borne.executer(str(corps.get("commande", "")))
                self.envoyer(200, json.dumps({"reponse": reponse, "heure": app.heure()}), "application/json")
            elif self.path == "/api/prix":
                self.envoyer(200, json.dumps({"texte": prix(corps)}), "application/json")
            elif self.path == "/api/reset":
                app.borne = Borne()
                self.envoyer(200, json.dumps({"reponse": f"Borne réinitialisée (horloge : {app.heure()})",
                                              "heure": app.heure()}), "application/json")
            else:
                self.envoyer(404, "{}", "application/json")
    return Gestionnaire


def lancer(port=8000, hote="127.0.0.1"):
    serveur = ThreadingHTTPServer((hote, port), fabriquer_gestionnaire(Application()))
    print(f"VéloCité ({LIVRAISON}) disponible sur http://{hote}:{port}  (Ctrl+C pour arrêter)", flush=True)
    try:
        serveur.serve_forever()
    except KeyboardInterrupt:
        pass
