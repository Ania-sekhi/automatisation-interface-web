"""VéloCité."""
__version__ = "4.0"
LIVRAISON = "Livraison 4"
