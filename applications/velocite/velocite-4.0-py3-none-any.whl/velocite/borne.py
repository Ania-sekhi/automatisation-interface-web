"""Borne VéloCité : simulateur interactif pour exécuter les tests manuels.

Lancement :  python -m velocite.borne        (depuis le dossier src/ ou une livraison historique)

L'horloge est simulée : la commande « attendre » fait avancer le temps, sans attendre réellement.
"""
import sys
from datetime import datetime, timedelta

from .location import TransitionInterdite
from .service import ServiceErreur, ServiceVeloCite
from .tarif import TarifErreur, formater

AIDE = """Commandes :
  client <nom> <âge> [abonne]        inscrire un client
  reserver <nom> <classique|electrique>
  deverrouiller <nom>
  attendre <minutes> | <mm:ss>        faire avancer l'horloge simulée
  panne <nom>                         signaler une panne
  rendre <nom>                        rendre le vélo (affiche la durée et le prix)
  payer <nom>
  annuler <nom>
  etat <nom>                          état de la dernière location du client
  paiement <accepte|refuse>           comportement de la banque simulée
  debits                              liste des débits effectués par la banque
  heure                               heure simulée
  aide | quitter"""


class BanqueSimulee:
    def __init__(self):
        self.accepte = True
        self.debits = []

    def debiter(self, client, centimes):
        self.debits.append((client, centimes))
        return self.accepte


class Borne:
    def __init__(self):
        self.banque = BanqueSimulee()
        self.service = ServiceVeloCite(self.banque)
        self.maintenant = datetime(2026, 1, 15, 9, 0, 0)
        self.locations = {}

    def location(self, nom):
        if nom not in self.locations:
            raise ServiceErreur(f"Aucune location pour {nom}")
        return self.locations[nom]

    def executer(self, ligne: str) -> str:
        mots = ligne.split()
        if not mots:
            return ""
        commande, args = mots[0].lower(), mots[1:]
        try:
            if commande == "aide":
                return AIDE
            if commande == "client":
                self.service.inscrire(args[0], int(args[1]), abonne=len(args) > 2 and args[2] == "abonne")
                return f"Client {args[0]} inscrit ({args[1]} ans{', abonné' if len(args) > 2 else ''})"
            if commande == "reserver":
                self.locations[args[0]] = self.service.reserver(args[0], args[1], self.maintenant)
                return f"Réservation confirmée pour {args[0]} (vélo {args[1]})"
            if commande == "deverrouiller":
                self.location(args[0]).deverrouiller(self.maintenant)
                return "Vélo déverrouillé, bonne route !"
            if commande == "attendre":
                minutes, _, secondes = args[0].partition(":")
                self.maintenant += timedelta(minutes=int(minutes), seconds=int(secondes or 0))
                return f"Heure simulée : {self.maintenant:%H:%M:%S}"
            if commande == "heure":
                return f"Heure simulée : {self.maintenant:%H:%M:%S}"
            if commande == "panne":
                self.location(args[0]).signaler_panne(self.maintenant)
                return "Panne enregistrée, la facturation est arrêtée"
            if commande == "rendre":
                loc = self.location(args[0])
                prix = self.service.terminer(loc, self.maintenant)
                minutes = max(1, -(-int((loc.fin_facturation - loc.debut).total_seconds()) // 60))
                return f"Location terminée : {minutes} min, prix {formater(prix)}"
            if commande == "payer":
                ok = self.service.payer(self.location(args[0]))
                return "Paiement accepté" if ok else "Paiement refusé"
            if commande == "annuler":
                self.location(args[0]).annuler(self.maintenant)
                return "Réservation annulée"
            if commande == "etat":
                return f"État : {self.location(args[0]).etat}"
            if commande == "paiement":
                self.banque.accepte = args[0] == "accepte"
                return f"Banque simulée : paiements {'acceptés' if self.banque.accepte else 'refusés'}"
            if commande == "debits":
                if not self.banque.debits:
                    return "Débits : aucun"
                return "Débits : " + ", ".join(f"{c} {formater(m)}" for c, m in self.banque.debits)
            return f"Commande inconnue : {commande} (tapez « aide »)"
        except (TarifErreur, ServiceErreur, TransitionInterdite) as erreur:
            return f"Erreur : {erreur}"
        except (IndexError, ValueError):
            return "Erreur : paramètres incorrects (tapez « aide »)"


def main():
    borne = Borne()
    print("Borne VéloCité (horloge simulée : 09:00:00). Tapez « aide ».")
    for ligne in sys.stdin if not sys.stdin.isatty() else iter(lambda: input("> "), None):
        if ligne.strip().lower() == "quitter":
            break
        reponse = borne.executer(ligne)
        if reponse:
            print(reponse)


if __name__ == "__main__":
    main()
