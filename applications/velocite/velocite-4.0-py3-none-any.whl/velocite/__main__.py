import argparse

from .web import lancer

parser = argparse.ArgumentParser(prog="velocite", description="Lance la borne VéloCité dans le navigateur")
parser.add_argument("--port", type=int, default=8000)
lancer(parser.parse_args().port)
