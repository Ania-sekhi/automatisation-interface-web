"""Calcul du prix d'une location (règles R-01 à R-08 de la spécification v1.1).

Tous les montants sont en centimes (entiers) pour éviter les erreurs d'arrondi.
"""

CLASSIQUE = "classique"
ELECTRIQUE = "electrique"

AGE_MIN = {CLASSIQUE: 14, ELECTRIQUE: 16}          # R-01
AGE_MAX = 120                                       # R-01
DUREE_TRANCHE = 30                                  # R-03 (minutes)
PRIX_TRANCHE = {CLASSIQUE: 100, ELECTRIQUE: 200}    # R-04
MINUTES_OFFERTES_ABONNE = 30                        # R-05
PLAFOND = {CLASSIQUE: 1500, ELECTRIQUE: 1500}       # R-06 (v1.2 : CR-01)
AGE_MAX_JEUNE, AGE_MIN_SENIOR = 17, 65              # R-07
REDUCTION_JEUNE, REDUCTION_SENIOR = 50, 30          # R-07 (%)
DUREE_MAX = 24 * 60                                 # R-08 (minutes)
PENALITE = 15000                                    # R-08


class TarifErreur(ValueError):
    """Données de tarification invalides."""


def verifier_eligibilite(type_velo: str, age: int) -> None:
    """R-01 : lève TarifErreur si le client ne peut pas louer ce type de vélo."""
    if type_velo not in AGE_MIN:
        raise TarifErreur(f"Type de vélo inconnu : {type_velo}")
    if not isinstance(age, int) or age > AGE_MAX or age < 0:
        raise TarifErreur("Âge invalide")
    if age < AGE_MIN[type_velo]:
        raise TarifErreur(f"Âge minimum pour un vélo {type_velo} : {AGE_MIN[type_velo]} ans")


def taux_reduction(age: int) -> int:
    """R-07 : pourcentage de réduction selon l'âge."""
    if age <= AGE_MAX_JEUNE:
        return REDUCTION_JEUNE
    if age >= AGE_MIN_SENIOR:
        return REDUCTION_SENIOR
    return 0


def calculer_prix(minutes: int, type_velo: str, age: int, abonne: bool = False) -> int:
    """Retourne le prix en centimes d'une location de `minutes` minutes."""
    verifier_eligibilite(type_velo, age)
    if not isinstance(minutes, int) or minutes < 1:
        raise TarifErreur("La durée doit être d'au moins 1 minute")       # R-02

    penalite = PENALITE if minutes > DUREE_MAX else 0                     # R-08
    minutes_comptees = min(minutes, DUREE_MAX)
    if abonne:                                                            # R-05
        minutes_comptees = max(0, minutes_comptees - MINUTES_OFFERTES_ABONNE)

    tranches = -(-minutes_comptees // DUREE_TRANCHE)                      # R-03 : arrondi supérieur
    montant = min(tranches * PRIX_TRANCHE[type_velo], PLAFOND[type_velo])  # R-04, R-06

    reduction = taux_reduction(age)                                       # R-07 : après le plafond
    montant = (montant * (100 - reduction) + 50) // 100                   # arrondi au centime le plus proche

    return montant + penalite                                             # R-08 : pénalité non réduite


def formater(centimes: int) -> str:
    """CA-02.2 : 1234 -> '12,34 €'."""
    return f"{centimes // 100},{centimes % 100:02d} €"
