"""VéloCité."""
__version__ = "5.0"
LIVRAISON = "Livraison 5"
