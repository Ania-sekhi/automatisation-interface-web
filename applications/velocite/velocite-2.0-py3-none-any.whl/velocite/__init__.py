"""VéloCité."""
__version__ = "2.0"
LIVRAISON = "Livraison 2"
